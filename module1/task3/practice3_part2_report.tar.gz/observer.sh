#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Ошибка: файл конфигурации $CONFIG_FILE не найден" >> "$LOG_FILE"
        exit 1
fi

is_process_running() {
        local script_name=$1
        local pid
        local cmdline

        for pid in /proc/[0-9]*; do
                if [ -f "${pid}/cmdline" ]; then
                        cmdline=$(tr '\0' ' ' < "${pid}/cmdline")
                        if [[ "$cmdline" == *"$script_name"* ]]; then
                                return 0
                        fi
                fi
        done

        return 1
}

while IFS= read -r script || [ -n "$script" ]; do
        script=$(echo "$script" | xargs)
        [[ -z "$script" || "$script" =~ ^# ]] && continue

        script_name=$(basename "$script")

        if ! is_process_running "$script_name"; then
                nohup "$script" > /dev/null 2>&1 &
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен скрипт: $script" >> "$LOG_FILE"
        fi
done < "$CONFIG_FILE"
