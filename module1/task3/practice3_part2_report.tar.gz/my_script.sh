#!/bin/bash

script_name=$(basename "$0")
if [[ "$script_name" == "template_task.sh" ]]; then
        echo "я бригадир, сам не работаю"
        exit 1
fi

report_file="report_${script_name%.*}.log"

pid=$$

start_time=$(date +%s)
current_date_time=$(date "+%Y-%m-%d %H:%M:%S")
echo "[$pid] $current_date_time Скрипт запущен" >> "$report_file"

random_seconds=$((RANDOM % 51 + 30))

sleep "$random_seconds"

end_time=$(date +%s)
duration_seconds=$((end_time - start_time))
minutes=$((duration_seconds / 60))
seconds=$((duration_seconds % 60))

current_date_time=$(date "+%Y-%m-%d %H:%M:%S")
echo "[$pid] $current_date_time Скрипт завершился, работал $minutes минут $seconds секунд" >> "$report_file"

