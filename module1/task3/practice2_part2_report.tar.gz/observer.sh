#!/bin/bash

CONFIG_FILE="observer.conf"

LOG_FILE="observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Ошибка: файл конфигурации $CONFIG_FILE не найден" >> "$LOG_FILE"
        exit 1
fi

while IFS= read -r script || [ -n "$script" ]; do
        script=$(echo "$script" | xargs)

        if [[ -z "$script" || "$script" =~ ^# ]]; then
                continue
        fi

        script_name=$(basename "$script")

        if ! pgrep -f "$script_name" > /dev/null 2>&1; then
                nohup "$script" > /dev/null 2>&1 &
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен скрипт: $script" >> "$LOG_FILE"
        fi
done < "$CONFIG_FILE"

